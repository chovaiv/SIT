Action
=======================
* Convert into a cookiecutter project
